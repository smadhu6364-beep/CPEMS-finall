<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if(strlen($_SESSION['cpmsaid'] == 0)){
      header('location:logout.php');
}else{
      ?>
      <!DOCTYPE html>
      <html lang="en">
      <head>
      <title>Curfew Pass Management System | Pass Report Details</title>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
      <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />
      </head>
      <body>
      <div id="wrapper">
            <?php include_once('includes/header.php');?>
            <?php include_once('includes/sliderbar.php');?>

           <div id="page-wrapper">
           <div class="row"> 
                 <div class="col-lg-12">
                       <h1 class="page-header">Between Dates Reports of Pass</h1>
                  </div>
                 </div>
                 <div class="row">
                       <div class="col-lg-12">
                             <div class="panel panel-default">
                                   <div class="panel-body">
                                         <div class="table-responsive">
                                               <?php
                                               $fdate=$_POST['fromdate'];
                                               $tdate=$_POST['todate'];
                                               ?>
                                               <h5 allign="center" styles="color:blue">Pass Report from <?php echo $fdate?> to <?php echo $tdate?></h5>
                                               <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                     <thead>
                                                           <tr>
                                                                 <th>S.NO</th>
                                                                 <th>Pass Number</th>
                                                                 <th>Full Name</th>
                                                                 <th>Contact Number</th>
                                                                 <th>Email</th>
                                                                 <th>Creation Date</th>
                                                                 <th>Action</th>
                                                           </tr>
                                                     </thead>
                                                     <tbody>
                                                           <?php
                                                           $sql="SELECT * from tblpass where date(PasscreationDate) between '$fdate' and '$tdate'";
                                                           $query=$dbh -> prepare($sql);
                                                           $query->execute();
                                                           $results=$query->fetchAll(PDO::FETCH_OBJ);

                                                           $cnt=1;
                                                           if($query->rowCount() > 0)
                                                           {
                                                                 foreach($results as $row)
                                                                 {
                                                                       ?>
                                                                       <tr>
                                                                    <td><?php echo htmlentities($cnt);?></td>
                                                                     <td><?php  echo htmlentities($row->PassNumber);?></td>
                                                                    <td><?php  echo htmlentities($row->FullName);?></td>
                                                                  <td><?php  echo htmlentities($row->ContactNumber);?></td>
                                                                   <td><?php  echo htmlentities($row->Email);?></td>
                                                                   <td><?php  echo htmlentities($row->PasscreationDate);?></td>
                                                                   <td><a href="view-pass-detail.php?viewid=<?php echo htmlentities ($row->ID);?>">View</a>  ||  <a href="edit-pass-detail.php?editid=<?php echo htmlentities ($row->ID);?>">Edit</a></td>
                </tr>
            <?php 
                 $cnt=$cnt+1;
               }}else{?>
               <tr>
                     <td colspan="8">No record found against between this date</td>

               </tr>
               <?php } ?>
                                                     </tbody>
                                               </table>
                                         </div>
                                         </div>
                                   </div>
                             </div>
                       </div>
                 </div>
            
      </div>
      <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>  
    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="assets/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>    
      </body>
      </html>
<?php } ?>

